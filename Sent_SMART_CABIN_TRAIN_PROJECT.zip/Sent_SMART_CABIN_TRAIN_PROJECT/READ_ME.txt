For contact, Send an Email to: samandarkhanafridi@gmail.com

/* =====================================================
 *  My name is Samandar Khan Afridi
 *  Please Subscribe to my Youtube Channel: https://www.youtube.com/channel/UC-DQMk_ktNYi_6tv4hIRLig
 *
 *  for more Electrical, Electronics & IoT Tutorials. Thank You.
 *  Dated: 21-January-2025
 *  ====================================================
*/