// Smart Autonomous Vehicle - mikroC for PIC18F45K22
// Libraries: UART, PWM, GPIO

// Pin Definitions
sbit Trigger_Left at RD0_bit;
sbit Echo_Left at RD1_bit;
sbit Trigger_Right at RD2_bit;
sbit Echo_Right at RD3_bit;
sbit IR_Left at RB2_bit;
sbit IR_Right at RB3_bit;
sbit Motor_Left_Forward at RC0_bit;
sbit Motor_Left_Backward at RC1_bit;
sbit Motor_Right_Forward at RC2_bit;
sbit Motor_Right_Backward at RC3_bit;
sbit Servo at RC5_bit;

// Function Prototypes
void initSystem();
void initPWM();
unsigned int measureDistanceLeft();
unsigned int measureDistanceRight();
void moveForward();
void turnLeft();
void turnRight();
void stop();
void setServoAngle(unsigned short angle);
void sendDataToESP(unsigned int leftDist, unsigned int rightDist, unsigned short irLeft, unsigned short irRight);

// Initialization
void initSystem() {
    TRISD = 0x0F; // RD0-RD3 as inputs for ultrasonic, others as outputs
    TRISB = 0x0C; // RB2, RB3 as inputs for IR sensors
    TRISC = 0x00; // RC0-RC5 as outputs for motors and servo

    UART1_Init(9600); // Initialize UART at 9600 baud rate
    initPWM(); // Initialize PWM
}

// Initialize PWM using CCP1 for Servo Control
void initPWM() {
    TRISC.F2 = 0; // Set RC2/CCP1 as output
    CCP1CON = 0x0C; // Set PWM mode
    PR2 = 255; // Set PWM period
    T2CON = 0x04; // Start Timer2 with 1:1 prescaler
}

// Measure Distance from Left Ultrasonic Sensor
unsigned int measureDistanceLeft() {
    unsigned int time = 0;
    Trigger_Left = 1;
    Delay_us(10);
    Trigger_Left = 0;
    while (!Echo_Left);
    while (Echo_Left) time++;
    return (time / 58); // Convert to cm
}

// Measure Distance from Right Ultrasonic Sensor
unsigned int measureDistanceRight() {
    unsigned int time = 0;
    Trigger_Right = 1;
    Delay_us(10);
    Trigger_Right = 0;
    while (!Echo_Right);
    while (Echo_Right) time++;
    return (time / 58); // Convert to cm
}

// Movement Functions
void moveForward() {
    Motor_Left_Forward = 1;
    Motor_Right_Forward = 1;
    Motor_Left_Backward = 0;
    Motor_Right_Backward = 0;
}

void turnLeft() {
    Motor_Left_Forward = 0;
    Motor_Right_Forward = 1;
    Motor_Left_Backward = 0;
    Motor_Right_Backward = 0;
}

void turnRight() {
    Motor_Left_Forward = 1;
    Motor_Right_Forward = 0;
    Motor_Left_Backward = 0;
    Motor_Right_Backward = 0;
}

void stop() {
    Motor_Left_Forward = 0;
    Motor_Right_Forward = 0;
    Motor_Left_Backward = 0;
    Motor_Right_Backward = 0;
}

// Servo Control
void setServoAngle(unsigned short angle) {
    unsigned short duty = (angle * 10) + 600; // Convert angle to duty cycle
    CCPR1L = duty >> 2; // Set high 8 bits
    CCP1CON.F5 = duty & 0x03; // Set low 2 bits
}

// Send Data to ESP-01
void sendDataToESP(unsigned int leftDist, unsigned int rightDist, unsigned short irLeft, unsigned short irRight) {
    UART1_Write_Text("UL: ");
    UART1_Write(leftDist);
    UART1_Write_Text(" UR: ");
    UART1_Write(rightDist);
    UART1_Write_Text(" IR_L: ");
    UART1_Write(irLeft ? '1' : '0');
    UART1_Write_Text(" IR_R: ");
    UART1_Write(irRight ? '1' : '0');
    UART1_Write_Text("\r\n");
}

// Main Program
void main() {
    unsigned int distanceLeft, distanceRight;

    initSystem();

    while (1) {
        distanceLeft = measureDistanceLeft();
        distanceRight = measureDistanceRight();

        sendDataToESP(distanceLeft, distanceRight, IR_Left, IR_Right);

        if (distanceLeft < 10) {
            turnRight();
            setServoAngle(135);
        } else if (distanceRight < 10) {
            turnLeft();
            setServoAngle(45);
        } else if (!IR_Left && IR_Right) {
            turnLeft();
            setServoAngle(45);
        } else if (IR_Left && !IR_Right) {
            turnRight();
            setServoAngle(135);
        } else {
            moveForward();
            setServoAngle(90);
        }
        Delay_ms(100);
    }
}
